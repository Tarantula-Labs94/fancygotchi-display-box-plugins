# FancyGotchi Theme Button Toggle + Splash Fix

A user-friendly Pwnagotchi / FancyGotchi plugin that toggles between two FancyGotchi themes using a GPIO button.

This version includes a setup wizard and the boot splash fix.

## What it does

- Toggles between two user-selected FancyGotchi themes.
- Lets the user choose the GPIO button.
- Writes the plugin config automatically.
- Always updates the generated FancyGotchi boot animation path so the splash matches the new theme.
- Supports Display HAT Mini buttons.
- Keeps theme names configurable, so it is not locked to vaultboy and cyber.

## Files

```text
plugins/theme_button.py
theme_button_setup.py
install.sh
uninstall.sh
README.md
docs/setup.md
optional/
LICENSE
```

## Quick install

Put this repo folder anywhere on your Pwnagotchi, like `/home/pi`.

Do not put the whole folder inside `custom-plugins`. The installer copies only the plugin file where it needs to go.

```bash
cd /home/pi
unzip fancygotchi-theme-button-wizard.zip
cd fancygotchi-theme-button-wizard
sudo bash install.sh
```

Then follow the wizard.

## Recommended default setup

For Display HAT Mini button A and vaultboy/cyber:

```toml
[main.plugins.theme_button]
enabled = true
button_pin = 5
theme_one = "vaultboy"
theme_two = "cyber"
restart_mode = "reboot"
debounce_seconds = 2
restart_delay = 2
```

The wizard can write this for you.

## Choosing your own themes

The wizard lists installed themes from:

```text
/usr/local/share/pwnagotchi/custom-plugins/themes/
```

You can pick by number or type the exact theme folder name.

Example:

```toml
theme_one = "MikuGotchi"
theme_two = "white-rabbit"
```

Theme names must match folder names exactly, including uppercase letters.

## Display HAT Mini GPIO buttons

```text
A = GPIO 5
B = GPIO 6
X = GPIO 16
Y = GPIO 24
```

## Boot splash fix

The boot splash fix is built in and always runs before reboot. FancyGotchi can generate this file:

```text
/usr/local/bin/boot_animation.py
```

Sometimes it keeps pointing at the old theme’s `img/boot` folder after a theme switch. This plugin can patch that file before rebooting.

Recommended:

```toml
restart_mode = "reboot"
```

## FancyGotchi requirement

This plugin needs FancyGotchi installed already.

The wizard checks for:

```text
/usr/local/share/pwnagotchi/custom-plugins/Fancygotchi.py
/usr/local/share/pwnagotchi/custom-plugins/themes/
```

If FancyGotchi is missing, install FancyGotchi first, then rerun the wizard.

Future versions may support installing FancyGotchi from an included zip placed in the `optional/` folder.

## Troubleshooting

Watch logs:

```bash
sudo journalctl -u pwnagotchi -f | grep -i "theme_button\|Fancygotchi\|error"
```

Check config:

```bash
grep -A8 -n "\[main.plugins.theme_button\]" /etc/pwnagotchi/config.toml
```

Check boot splash path:

```bash
sudo grep -n "themes/.*/img/boot" /usr/local/bin/boot_animation.py
```

It should match the theme you just switched to.

## Uninstall

```bash
cd /home/pi/fancygotchi-theme-button-wizard
sudo bash uninstall.sh
```
