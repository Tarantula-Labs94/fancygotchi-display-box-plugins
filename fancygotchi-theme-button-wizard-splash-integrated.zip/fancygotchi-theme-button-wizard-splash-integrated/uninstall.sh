#!/usr/bin/env bash
set -e

PLUGIN="/usr/local/share/pwnagotchi/custom-plugins/theme_button.py"
CONFIG="/etc/pwnagotchi/config.toml"
STAMP="$(date +%Y%m%d-%H%M%S)"

echo "FancyGotchi Theme Button Toggle Uninstaller"
echo "------------------------------------------"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run with sudo:"
  echo "sudo bash uninstall.sh"
  exit 1
fi

if [ -f "$PLUGIN" ]; then
  cp "$PLUGIN" "$PLUGIN.bak-uninstall-$STAMP"
  rm "$PLUGIN"
  echo "Removed plugin: $PLUGIN"
else
  echo "Plugin not found: $PLUGIN"
fi

if [ -f "$CONFIG" ]; then
  cp "$CONFIG" "$CONFIG.bak-theme-button-uninstall-$STAMP"
  python3 - <<'PY'
from pathlib import Path

config = Path("/etc/pwnagotchi/config.toml")
lines = config.read_text().splitlines(keepends=True)

start = None
end = None

for i, line in enumerate(lines):
    if line.strip() == "[main.plugins.theme_button]":
        start = i
        end = len(lines)
        for j in range(i + 1, len(lines)):
            stripped = lines[j].strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                end = j
                break
        break

if start is not None:
    lines = lines[:start] + lines[end:]
    config.write_text("".join(lines))
    print("Removed [main.plugins.theme_button] from config.")
else:
    print("No theme_button config section found.")
PY
fi

echo "Restarting Pwnagotchi..."
systemctl restart pwnagotchi || true
echo "Done."
