# Setup Wizard Walkthrough

## User experience

The user SSHs into their Pwnagotchi and runs:

```bash
cd /home/pi
unzip fancygotchi-theme-button-wizard.zip
cd fancygotchi-theme-button-wizard
sudo bash install.sh
```

The wizard then checks for:

```text
/etc/pwnagotchi/config.toml
/usr/local/share/pwnagotchi/custom-plugins/
/usr/local/share/pwnagotchi/custom-plugins/Fancygotchi.py
/usr/local/share/pwnagotchi/custom-plugins/themes/
```

Then it asks:

```text
Choose your button:

1) Display HAT Mini A  GPIO 5
2) Display HAT Mini B  GPIO 6
3) Display HAT Mini X  GPIO 16
4) Display HAT Mini Y  GPIO 24
5) Custom GPIO
```

Then it lists installed themes and asks for two choices.

Then restart mode:

```text
1) Reboot device after button press, recommended
2) Restart Pwnagotchi service only, faster but splash may not update
```

Finally it shows the settings and asks before changing anything:

```text
Ready to install with these settings:

Button GPIO: 5
Theme one: vaultboy
Theme two: cyber
Restart mode: reboot
Splash fix: always enabled

Install now? [y/N]:
```

After install, the button toggles between the two chosen themes.
