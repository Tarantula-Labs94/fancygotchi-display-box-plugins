import time
import threading
import logging
import subprocess
import os
import re

import RPi.GPIO as GPIO
import pwnagotchi.plugins as plugins


class ThemeButton(plugins.Plugin):
    __author__ = "TarantulaLabs"
    __version__ = "1.6.0"
    __license__ = "GPL3"
    __description__ = "Toggles FancyGotchi between two configurable themes using a GPIO button and always updates the boot splash path."

    def on_loaded(self):
        self.button_pin = int(self.options.get("button_pin", 5))
        self.theme_one = self.options.get("theme_one", "vaultboy")
        self.theme_two = self.options.get("theme_two", "cyber")
        self.restart_mode = self.options.get("restart_mode", "reboot")
        self.config_file = self.options.get("config_file", "/etc/pwnagotchi/config.toml")
        self.debounce_seconds = float(self.options.get("debounce_seconds", 2))
        self.restart_delay = float(self.options.get("restart_delay", 2))
        self.update_boot_animation = True

        self.last_press = 0
        self.next_theme = None

        try:
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.add_event_detect(
                self.button_pin,
                GPIO.FALLING,
                callback=self.button_pressed,
                bouncetime=500
            )

            logging.info(
                "[theme_button] loaded on GPIO %s, toggle: %s <-> %s, restart_mode=%s"
                % (self.button_pin, self.theme_one, self.theme_two, self.restart_mode)
            )

        except Exception as e:
            logging.error("[theme_button] GPIO setup failed: %s" % e)

    def get_current_theme(self):
        try:
            in_fancy = False

            with open(self.config_file, "r") as f:
                for line in f:
                    stripped = line.strip()

                    if stripped.startswith("[") and stripped.endswith("]"):
                        in_fancy = stripped == "[main.plugins.Fancygotchi]"

                    if in_fancy and stripped.startswith("theme"):
                        return stripped.split("=", 1)[1].strip().replace('"', "")

        except Exception as e:
            logging.error("[theme_button] could not read current theme: %s" % e)

        return None

    def set_theme(self, new_theme):
        try:
            with open(self.config_file, "r") as f:
                lines = f.readlines()

            in_fancy = False
            changed = False
            new_lines = []

            for line in lines:
                stripped = line.strip()

                if stripped.startswith("[") and stripped.endswith("]"):
                    in_fancy = stripped == "[main.plugins.Fancygotchi]"

                if in_fancy and stripped.startswith("theme"):
                    new_lines.append('theme = "%s"\n' % new_theme)
                    changed = True
                else:
                    new_lines.append(line)

            if not changed:
                logging.error("[theme_button] could not find Fancygotchi theme line")
                return False

            with open(self.config_file, "w") as f:
                f.writelines(new_lines)

            logging.info("[theme_button] changed theme to %s" % new_theme)
            return True

        except Exception as e:
            logging.error("[theme_button] could not set theme: %s" % e)
            return False

    def update_boot_animation_path(self, new_theme):
        try:
            boot_file = "/usr/local/bin/boot_animation.py"
            new_boot_path = "/usr/local/share/pwnagotchi/custom-plugins/themes/%s/img/boot" % new_theme

            if not os.path.exists(new_boot_path):
                logging.error("[theme_button] theme boot folder missing: %s" % new_boot_path)
                return False

            if not os.path.exists(boot_file):
                logging.error("[theme_button] boot animation file missing: %s" % boot_file)
                return False

            with open(boot_file, "r") as f:
                data = f.read()

            updated = re.sub(
                r"/usr/local/share/pwnagotchi/custom-plugins/themes/[^/]+/img/boot",
                new_boot_path,
                data
            )

            if updated == data:
                logging.error("[theme_button] boot animation path was not found in %s" % boot_file)
                return False

            with open(boot_file, "w") as f:
                f.write(updated)

            logging.info("[theme_button] boot animation path updated to %s" % new_boot_path)
            return True

        except Exception as e:
            logging.error("[theme_button] could not update boot animation path: %s" % e)
            return False

    def button_pressed(self, channel):
        now = time.time()

        if now - self.last_press < self.debounce_seconds:
            return

        self.last_press = now

        current = self.get_current_theme()

        if current == self.theme_two:
            next_theme = self.theme_one
        else:
            next_theme = self.theme_two

        self.next_theme = next_theme

        logging.info(
            "[theme_button] button pressed, current=%s, switching to %s"
            % (current, next_theme)
        )

        if self.set_theme(next_theme):
            threading.Thread(target=self.restart_pwnagotchi, daemon=True).start()

    def restart_pwnagotchi(self):
        time.sleep(self.restart_delay)

        if self.next_theme:
            self.update_boot_animation_path(self.next_theme)

        if self.restart_mode == "restart":
            subprocess.call(["systemctl", "restart", "pwnagotchi"])
        else:
            subprocess.call(["reboot"])

    def on_unload(self, ui):
        try:
            GPIO.remove_event_detect(self.button_pin)
        except Exception:
            pass
