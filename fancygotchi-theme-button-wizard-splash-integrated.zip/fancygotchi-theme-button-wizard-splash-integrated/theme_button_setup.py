#!/usr/bin/env python3
import os
import sys
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

CONFIG_FILE = Path("/etc/pwnagotchi/config.toml")
PLUGIN_DIR = Path("/usr/local/share/pwnagotchi/custom-plugins")
THEMES_DIR = PLUGIN_DIR / "themes"
FANCY_FILE = PLUGIN_DIR / "Fancygotchi.py"
PLUGIN_NAME = "theme_button.py"


def run(cmd, check=True):
    print("+ " + " ".join(cmd))
    return subprocess.run(cmd, check=check)


def ask(prompt, default=None):
    if default is None:
        value = input(prompt + " ").strip()
    else:
        value = input(f"{prompt} [{default}]: ").strip()
        if value == "":
            value = str(default)
    return value


def yes_no(prompt, default=True):
    suffix = "[Y/n]" if default else "[y/N]"
    value = input(f"{prompt} {suffix}: ").strip().lower()
    if value == "":
        return default
    return value in ["y", "yes"]


def require_root():
    if os.geteuid() != 0:
        print("Run this with sudo:")
        print("sudo python3 theme_button_setup.py")
        sys.exit(1)


def find_source_plugin():
    here = Path(__file__).resolve().parent
    candidates = [
        here / "plugins" / PLUGIN_NAME,
        here / PLUGIN_NAME,
        Path("/tmp") / PLUGIN_NAME,
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    print("Could not find theme_button.py.")
    print("Put theme_button_setup.py next to the repo folder or run install.sh from the repo.")
    sys.exit(1)


def backup_file(path):
    if not path.exists():
        return None

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = Path(str(path) + f".bak-theme-button-{stamp}")
    shutil.copy2(path, backup)
    return backup


def list_themes():
    if not THEMES_DIR.exists():
        return []

    themes = []
    for item in THEMES_DIR.iterdir():
        if item.is_dir():
            themes.append(item.name)

    return sorted(themes, key=lambda x: x.lower())


def choose_theme(themes, prompt, default):
    if not themes:
        return ask(prompt, default)

    print("")
    print("Installed FancyGotchi themes:")
    for index, theme in enumerate(themes, start=1):
        print(f"{index}) {theme}")

    while True:
        value = ask(prompt, default)
        if value.isdigit():
            idx = int(value)
            if 1 <= idx <= len(themes):
                return themes[idx - 1]
            print("That number is not in the list.")
            continue

        if value in themes:
            return value

        print(f"Theme not found: {value}")
        close = [theme for theme in themes if theme.lower() == value.lower()]
        if close:
            print(f"Did you mean: {close[0]}?")
        print("Type the exact folder name or number.")


def choose_button():
    print("")
    print("Choose your button:")
    print("1) Display HAT Mini A  GPIO 5")
    print("2) Display HAT Mini B  GPIO 6")
    print("3) Display HAT Mini X  GPIO 16")
    print("4) Display HAT Mini Y  GPIO 24")
    print("5) Custom GPIO")

    value = ask("Select button", "1")
    mapping = {
        "1": 5,
        "2": 6,
        "3": 16,
        "4": 24,
    }

    if value in mapping:
        return mapping[value]

    if value == "5":
        return int(ask("Enter GPIO BCM pin number", "5"))

    try:
        return int(value)
    except ValueError:
        print("Invalid button choice. Using GPIO 5.")
        return 5


def ensure_plugin_dir():
    PLUGIN_DIR.mkdir(parents=True, exist_ok=True)


def install_plugin(source):
    destination = PLUGIN_DIR / PLUGIN_NAME
    if destination.exists():
        backup = backup_file(destination)
        print(f"Existing plugin backed up to: {backup}")

    shutil.copy2(source, destination)
    print(f"Installed plugin to: {destination}")


def section_lines(settings):
    bool_text = "true" if settings["update_boot_animation"] else "false"
    return [
        "[main.plugins.theme_button]\n",
        "enabled = true\n",
        f"button_pin = {settings['button_pin']}\n",
        f'theme_one = "{settings["theme_one"]}"\n',
        f'theme_two = "{settings["theme_two"]}"\n',
        f'restart_mode = "{settings["restart_mode"]}"\n',
        f"debounce_seconds = {settings['debounce_seconds']}\n",
        f"restart_delay = {settings['restart_delay']}\n",
        f"update_boot_animation = {bool_text}\n",
    ]


def update_config(settings):
    if not CONFIG_FILE.exists():
        print(f"Could not find config file: {CONFIG_FILE}")
        sys.exit(1)

    backup = backup_file(CONFIG_FILE)
    print(f"Config backup saved to: {backup}")

    lines = CONFIG_FILE.read_text().splitlines(keepends=True)

    start = None
    end = None

    for i, line in enumerate(lines):
        if line.strip() == "[main.plugins.theme_button]":
            start = i
            end = len(lines)
            for j in range(i + 1, len(lines)):
                stripped = lines[j].strip()
                if stripped.startswith("[") and stripped.endswith("]"):
                    end = j
                    break
            break

    new_section = section_lines(settings)

    if start is None:
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        lines.append("\n")
        lines.extend(new_section)
    else:
        lines = lines[:start] + new_section + lines[end:]

    CONFIG_FILE.write_text("".join(lines))
    print("Config updated.")


def fancy_check():
    print("")
    print("Checking FancyGotchi...")
    if FANCY_FILE.exists():
        print("FancyGotchi plugin found.")
    else:
        print("FancyGotchi plugin was not found.")
        print("This theme button plugin needs FancyGotchi installed first.")
        print("")
        print("If you have Fancygotchi-2.0.8.zip, place it next to this installer or install FancyGotchi manually.")
        print("Then open the Pwnagotchi Web UI, enable FancyGotchi, select any theme once, and rerun this setup.")
        if not yes_no("Continue anyway?", False):
            sys.exit(1)

    if THEMES_DIR.exists():
        print("Themes folder found.")
    else:
        print("Themes folder not found. The setup can continue, but no themes can be listed.")


def compile_check():
    plugin_path = PLUGIN_DIR / PLUGIN_NAME
    run(["python3", "-m", "py_compile", str(plugin_path)])


def main():
    require_root()

    print("FancyGotchi Theme Button Toggle Setup")
    print("------------------------------------")
    print("This installs the button plugin and updates /etc/pwnagotchi/config.toml.")
    print("Backups will be made first.")
    print("")

    if not yes_no("Continue?", True):
        print("Cancelled.")
        return

    ensure_plugin_dir()
    fancy_check()

    themes = list_themes()
    button_pin = choose_button()
    theme_one = choose_theme(themes, "Choose theme one", "vaultboy")
    theme_two = choose_theme(themes, "Choose theme two", "cyber")

    print("")
    print("Restart mode:")
    print("1) Reboot device after button press, recommended")
    print("2) Restart Pwnagotchi service only, faster but splash may not update")
    restart_choice = ask("Choose", "1")
    restart_mode = "restart" if restart_choice == "2" else "reboot"

    settings = {
        "button_pin": button_pin,
        "theme_one": theme_one,
        "theme_two": theme_two,
        "restart_mode": restart_mode,
        "debounce_seconds": 2,
        "restart_delay": 2,
        "update_boot_animation": True,
    }

    print("")
    print("Ready to install with these settings:")
    print(f"Button GPIO: {settings['button_pin']}")
    print(f"Theme one: {settings['theme_one']}")
    print(f"Theme two: {settings['theme_two']}")
    print(f"Restart mode: {settings['restart_mode']}")
    print("Splash fix: always enabled")
    print("")

    if not yes_no("Install now?", False):
        print("Cancelled.")
        return

    source = find_source_plugin()
    install_plugin(source)
    update_config(settings)
    compile_check()

    print("")
    print("Install complete.")
    print("")
    print("Press your selected button to toggle:")
    print(f"{settings['theme_one']} <-> {settings['theme_two']}")
    print("")
    print("Watch logs with:")
    print('sudo journalctl -u pwnagotchi -f | grep -i "theme_button\\|error"')
    print("")

    if yes_no("Restart Pwnagotchi now?", True):
        run(["systemctl", "restart", "pwnagotchi"], check=False)


if __name__ == "__main__":
    main()
