#!/usr/bin/env bash
set -e

echo "FancyGotchi Theme Button Toggle Installer"
echo "----------------------------------------"

if [ "$(id -u)" -ne 0 ]; then
  echo "Please run with sudo:"
  echo "sudo bash install.sh"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -f "$SCRIPT_DIR/theme_button_setup.py" ]; then
  echo "theme_button_setup.py not found next to install.sh"
  exit 1
fi

python3 "$SCRIPT_DIR/theme_button_setup.py"
