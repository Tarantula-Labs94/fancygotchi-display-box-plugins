# Add the Cracked Count Box Plugin to an Existing Repo

This add-on includes only the files needed to add the Cracked Count Box plugin to an existing FancyGotchi display box plugins repository.

No real WPA-SEC API key is included.

## Files included

```text
plugins/cracked_count_box.py
docs/cracked-count-box.md
README-ADD-CRACKED-COUNTER.md
```

## What to upload to GitHub

Upload these two files into your existing repository:

```text
plugins/cracked_count_box.py
docs/cracked-count-box.md
```

Then update your main `README.md` with a link like this:

```md
## Cracked Count Box

Adds a small display number for cracked WPA results downloaded locally from WPA-SEC.

See: [docs/cracked-count-box.md](docs/cracked-count-box.md)
```

## Config lines users need

In `/etc/pwnagotchi/config.toml`, enable WPA-SEC result downloads:

```toml
main.plugins.wpa-sec.download_results = true
```

Use a placeholder in public guides. Never commit a real key:

```toml
main.plugins.wpa-sec.api_key = "YOUR_WPA_SEC_API_KEY"
```

Enable the cracked counter plugin:

```toml
main.plugins.cracked_count_box.enabled = true
```

## Default position

The default position in the plugin is:

```python
position=(225, 170),
```

This was set for a box below the deauth counter on a FancyGotchi Display HAT Mini layout.
