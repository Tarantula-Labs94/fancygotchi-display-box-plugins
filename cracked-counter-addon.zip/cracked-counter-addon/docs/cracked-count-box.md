# Cracked Count Box Plugin

This plugin adds a small number to a FancyGotchi theme box that shows how many cracked WPA results have been downloaded locally to the Pwnagotchi.

It does **not** crack passwords by itself. It only counts local result/potfile lines that already exist on your Pwnagotchi.

> Do not upload your real WPA-SEC API key to GitHub.

---

## 1. Copy the plugin

Copy this file to your Pwnagotchi custom plugins folder:

```bash
sudo cp plugins/cracked_count_box.py /usr/local/share/pwnagotchi/custom-plugins/
```

If you are using the GitHub website instead of cloning the repo, open `plugins/cracked_count_box.py`, copy the code, and paste it into:

```bash
sudo nano /usr/local/share/pwnagotchi/custom-plugins/cracked_count_box.py
```

Save with:

```text
CTRL + O
Enter
CTRL + X
```

---

## 2. Enable WPA-SEC result downloads

Open your config:

```bash
sudo nano /etc/pwnagotchi/config.toml
```

Find this line:

```toml
main.plugins.wpa-sec.download_results = false
```

Change it to:

```toml
main.plugins.wpa-sec.download_results = true
```

Example WPA-SEC config with a safe placeholder key:

```toml
main.plugins.wpa-sec.enabled = true
main.plugins.wpa-sec.api_key = "YOUR_WPA_SEC_API_KEY"
main.plugins.wpa-sec.api_url = "https://wpa-sec.stanev.org"
main.plugins.wpa-sec.download_results = true
main.plugins.wpa-sec.download_interval = 3600
```

Never commit your real API key.

---

## 3. Enable the cracked count plugin

In `config.toml`, add:

```toml
main.plugins.cracked_count_box.enabled = true
```

Example with the other display box plugins:

```toml
main.plugins.handshake_count_box.enabled = true
main.plugins.deauth_count_box.enabled = true
main.plugins.cracked_count_box.enabled = true
```

Save with:

```text
CTRL + O
Enter
CTRL + X
```

---

## 4. Test before restarting

Test the plugin:

```bash
sudo python3 -m py_compile /usr/local/share/pwnagotchi/custom-plugins/cracked_count_box.py
```

If it prints nothing, the plugin file is good.

Test your TOML:

```bash
python3 -c "import toml; toml.load('/etc/pwnagotchi/config.toml'); print('TOML OK')"
```

If it says `TOML OK`, restart Pwnagotchi:

```bash
sudo systemctl restart pwnagotchi
```

---

## 5. Placement

Default position:

```python
position=(225, 170),
```

To move it, open the plugin:

```bash
sudo nano /usr/local/share/pwnagotchi/custom-plugins/cracked_count_box.py
```

Find `position=(225, 170),` and adjust the numbers.

```text
Bigger first number = move right
Smaller first number = move left

Bigger second number = move down
Smaller second number = move up
```

Restart after editing:

```bash
sudo systemctl restart pwnagotchi
```

---

## How long does it take to update?

The counter updates after cracked results are downloaded locally to the Pwnagotchi.

If your config says:

```toml
main.plugins.wpa-sec.download_interval = 3600
```

then Pwnagotchi checks about once per hour.

The flow is:

```text
WPA-SEC cracks result online
Pwnagotchi downloads result locally
Cracked Count Box finds local result
Number updates on screen
```

So the website may update before the screen updates.

---

## Troubleshooting

Check if the plugin exists:

```bash
ls -l /usr/local/share/pwnagotchi/custom-plugins/ | grep cracked
```

Check if it is enabled:

```bash
grep -n "cracked_count_box" /etc/pwnagotchi/config.toml
```

Check WPA-SEC settings without showing only one secret key line publicly:

```bash
grep -n "wpa-sec" /etc/pwnagotchi/config.toml
```

Check for local result files:

```bash
sudo find /root /root/handshakes /var/tmp/pwnagotchi -iname "*pot*" -o -iname "*result*" -o -iname "*crack*" 2>/dev/null
```

Check logs:

```bash
sudo journalctl -u pwnagotchi -n 100 --no-pager | grep -i "cracked_count\|wpa\|error"
```
