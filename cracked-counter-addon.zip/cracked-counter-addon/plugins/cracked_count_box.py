import os
import glob
import logging

import pwnagotchi.plugins as plugins
from pwnagotchi.ui.components import LabeledValue
import pwnagotchi.ui.fonts as fonts
from pwnagotchi.ui.view import BLACK


# Change position=(x, y) below to move the number on screen.
# x = left/right, y = up/down.
# This plugin counts local WPA-SEC cracked result/potfile lines.

class CrackedCountBox(plugins.Plugin):
    __author__ = "TarantulaLabs"
    __version__ = "1.0.0"
    __license__ = "GPL3"
    __description__ = "Shows cracked WPA result count as a small number in a theme box."

    def on_loaded(self):
        logging.info("[cracked_count_box] plugin loaded")

    def on_ui_setup(self, ui):
        ui.add_element(
            "cracked_count_box",
            LabeledValue(
                color=BLACK,
                label="",
                value="0",
                position=(225, 170),
                label_font=fonts.Bold,
                text_font=fonts.Bold,
            ),
        )

    def find_result_files(self):
        search_paths = [
            "/root/handshakes",
            "/root",
            "/etc/pwnagotchi",
            "/var/tmp/pwnagotchi",
        ]

        patterns = [
            "*.potfile",
            "*.pot",
            "*potfile*",
            "*crack*",
            "*result*",
            "*wpa-sec*",
            "*wpasec*",
        ]

        found = []
        for path in search_paths:
            for pattern in patterns:
                found.extend(glob.glob(os.path.join(path, pattern)))

        return list(set(found))

    def count_cracked_lines(self):
        result_files = self.find_result_files()
        cracked = set()

        for result_file in result_files:
            try:
                if not os.path.isfile(result_file):
                    continue

                with open(result_file, "r", errors="ignore") as f:
                    for line in f:
                        line = line.strip()

                        if not line:
                            continue

                        if line.startswith("#"):
                            continue

                        if ":" in line:
                            cracked.add(line)

            except Exception as e:
                logging.error("[cracked_count_box] could not read %s: %s" % (result_file, e))

        return len(cracked)

    def on_ui_update(self, ui):
        try:
            count = self.count_cracked_lines()
            ui.set("cracked_count_box", str(count))
        except Exception as e:
            logging.error("[cracked_count_box] error: %s" % e)
            ui.set("cracked_count_box", "?")

    def on_unload(self, ui):
        with ui._lock:
            ui.remove_element("cracked_count_box")
