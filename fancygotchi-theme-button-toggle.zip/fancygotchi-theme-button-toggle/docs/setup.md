# Setup Guide

## 1. Copy the plugin

```bash
sudo cp plugins/theme_button.py /usr/local/share/pwnagotchi/custom-plugins/theme_button.py
```

## 2. Enable it

Add this to `/etc/pwnagotchi/config.toml`:

```toml
[main.plugins.theme_button]
enabled = true
button_pin = 5
theme_one = "vaultboy"
theme_two = "cyber"
restart_mode = "restart"
debounce_seconds = 2
restart_delay = 2
```

## 3. Change the themes

List your installed themes:

```bash
ls -1 /usr/local/share/pwnagotchi/custom-plugins/themes
```

Set `theme_one` and `theme_two` to the exact folder names.

## 4. Choose restart behavior

Fast service restart:

```toml
restart_mode = "restart"
```

Full reboot for better splash-screen matching:

```toml
restart_mode = "reboot"
```

## 5. Restart Pwnagotchi

```bash
sudo systemctl restart pwnagotchi
```

## 6. Watch logs while testing

```bash
sudo journalctl -u pwnagotchi -f | grep -i "theme_button\|Fancygotchi\|error"
```

Press the selected button.

## Display HAT Mini GPIO buttons

```text
A = GPIO 5
B = GPIO 6
X = GPIO 16
Y = GPIO 24
```
