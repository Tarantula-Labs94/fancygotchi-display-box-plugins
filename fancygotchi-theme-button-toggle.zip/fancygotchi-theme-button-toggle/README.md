# FancyGotchi Theme Button Toggle

A small Pwnagotchi/FancyGotchi plugin that lets you toggle between two FancyGotchi themes using a front GPIO button. It was built for Display HAT Mini, but it can work with any button wired to a GPIO pin.

This version is **not locked to cyber and vaultboy**. You choose the two theme names in `config.toml`.

## What it does

Press one button and the plugin will:

1. Read the current FancyGotchi theme from `/etc/pwnagotchi/config.toml`
2. Switch to the other configured theme
3. Restart Pwnagotchi or reboot the device, depending on your setting

Example:

```text
press button -> theme_one
press again -> theme_two
press again -> theme_one
```

## Files

```text
plugins/theme_button.py
README.md
docs/setup.md
```

## Install

Copy the plugin into your custom plugins folder:

```bash
sudo cp plugins/theme_button.py /usr/local/share/pwnagotchi/custom-plugins/theme_button.py
```

Or create it directly on the Pwnagotchi:

```bash
sudo nano /usr/local/share/pwnagotchi/custom-plugins/theme_button.py
```

Then paste the contents of `plugins/theme_button.py`.

Test the plugin syntax:

```bash
sudo python3 -m py_compile /usr/local/share/pwnagotchi/custom-plugins/theme_button.py
```

No output means the file compiled correctly.

## Enable in config.toml

Open your config:

```bash
sudo nano /etc/pwnagotchi/config.toml
```

Add this as its own plugin section. Do **not** put it inside `[main.plugins.Fancygotchi]`.

```toml
[main.plugins.theme_button]
enabled = true
button_pin = 5
theme_one = "vaultboy"
theme_two = "cyber"
restart_mode = "restart"
debounce_seconds = 2
restart_delay = 2
```

Save and restart:

```bash
sudo systemctl restart pwnagotchi
```

## Display HAT Mini button pins

For Display HAT Mini, the front buttons commonly map to:

```text
A = GPIO 5
B = GPIO 6
X = GPIO 16
Y = GPIO 24
```

So this line controls which button is used:

```toml
button_pin = 5
```

Change it to another GPIO if you want a different button.

## Choose your themes

Your themes live here:

```bash
ls -1 /usr/local/share/pwnagotchi/custom-plugins/themes
```

Use the folder names exactly. For example:

```toml
theme_one = "vaultboy"
theme_two = "cyber"
```

or:

```toml
theme_one = "MikuGotchi"
theme_two = "white-rabbit"
```

## Restart mode

You have two choices:

```toml
restart_mode = "restart"
```

This restarts only the Pwnagotchi service. It is faster.

```toml
restart_mode = "reboot"
```

This reboots the whole device. It is slower, but it may make the FancyGotchi boot/splash animation match the new theme more reliably.

## Check logs

Watch the plugin logs:

```bash
sudo journalctl -u pwnagotchi -f | grep -i "theme_button\|Fancygotchi\|error"
```

Press the button and you should see something like:

```text
[theme_button] button pressed, current=vaultboy, switching to cyber
[theme_button] changed theme to cyber
```

Stop watching logs with:

```text
CTRL + C
```

## Test which button is which

Stop Pwnagotchi first because the plugin may already be using the GPIO pin:

```bash
sudo systemctl stop pwnagotchi
```

Then run:

```bash
sudo python3 - <<'PY'
import RPi.GPIO as GPIO
import time

buttons = {
    5: "A",
    6: "B",
    16: "X",
    24: "Y",
}

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

for pin in buttons:
    GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

print("Press the Display HAT Mini buttons. CTRL+C to stop.")

try:
    last = {}
    while True:
        for pin, name in buttons.items():
            pressed = GPIO.input(pin) == 0
            if pressed and not last.get(pin, False):
                print("Pressed %s on GPIO %s" % (name, pin))
            last[pin] = pressed
        time.sleep(0.05)

except KeyboardInterrupt:
    GPIO.cleanup()
    print("Done.")
PY
```

Start Pwnagotchi again when done:

```bash
sudo systemctl start pwnagotchi
```

## Notes

This plugin edits the FancyGotchi theme line in:

```text
/etc/pwnagotchi/config.toml
```

It looks specifically for:

```toml
[main.plugins.Fancygotchi]
theme = "your-theme"
```

If your config uses a different section name or your theme line is missing, the plugin will log an error and will not change the theme.

## Safety

Make a backup before changing plugins or config:

```bash
sudo cp /etc/pwnagotchi/config.toml /etc/pwnagotchi/config.toml.bak
```
