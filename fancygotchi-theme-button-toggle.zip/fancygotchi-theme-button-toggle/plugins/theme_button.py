import time
import threading
import logging
import subprocess

import RPi.GPIO as GPIO
import pwnagotchi.plugins as plugins


class ThemeButton(plugins.Plugin):
    __author__ = "TarantulaLabs"
    __version__ = "1.3.0"
    __license__ = "GPL3"
    __description__ = "Toggles FancyGotchi between two configurable themes using a GPIO button."

    def on_loaded(self):
        self.button_pin = int(self.options.get("button_pin", 5))
        self.theme_one = self.options.get("theme_one", "vaultboy")
        self.theme_two = self.options.get("theme_two", "cyber")
        self.config_file = self.options.get("config_file", "/etc/pwnagotchi/config.toml")
        self.restart_mode = self.options.get("restart_mode", "restart")
        self.debounce_seconds = float(self.options.get("debounce_seconds", 2))
        self.restart_delay = float(self.options.get("restart_delay", 2))
        self.last_press = 0

        try:
            GPIO.setwarnings(False)
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(self.button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            GPIO.add_event_detect(
                self.button_pin,
                GPIO.FALLING,
                callback=self.button_pressed,
                bouncetime=500
            )
            logging.info(
                "[theme_button] loaded on GPIO %s, toggle: %s <-> %s, restart_mode=%s" %
                (self.button_pin, self.theme_one, self.theme_two, self.restart_mode)
            )
        except Exception as e:
            logging.error("[theme_button] GPIO setup failed: %s" % e)

    def get_current_theme(self):
        try:
            in_fancy = False

            with open(self.config_file, "r") as f:
                for line in f:
                    stripped = line.strip()

                    if stripped.startswith("[") and stripped.endswith("]"):
                        in_fancy = stripped == "[main.plugins.Fancygotchi]"

                    if in_fancy and stripped.startswith("theme"):
                        return stripped.split("=", 1)[1].strip().replace('"', "").replace("'", "")

        except Exception as e:
            logging.error("[theme_button] could not read current theme: %s" % e)

        return None

    def set_theme(self, new_theme):
        try:
            with open(self.config_file, "r") as f:
                lines = f.readlines()

            in_fancy = False
            changed = False
            new_lines = []

            for line in lines:
                stripped = line.strip()

                if stripped.startswith("[") and stripped.endswith("]"):
                    in_fancy = stripped == "[main.plugins.Fancygotchi]"

                if in_fancy and stripped.startswith("theme"):
                    new_lines.append('theme = "%s"\n' % new_theme)
                    changed = True
                else:
                    new_lines.append(line)

            if not changed:
                logging.error("[theme_button] could not find Fancygotchi theme line")
                return False

            with open(self.config_file, "w") as f:
                f.writelines(new_lines)

            logging.info("[theme_button] changed theme to %s" % new_theme)
            return True

        except Exception as e:
            logging.error("[theme_button] could not set theme: %s" % e)
            return False

    def button_pressed(self, channel):
        now = time.time()
        if now - self.last_press < self.debounce_seconds:
            return

        self.last_press = now
        current = self.get_current_theme()

        if current == self.theme_two:
            next_theme = self.theme_one
        else:
            next_theme = self.theme_two

        logging.info(
            "[theme_button] button pressed, current=%s, switching to %s" %
            (current, next_theme)
        )

        if self.set_theme(next_theme):
            threading.Thread(target=self.restart_pwnagotchi, daemon=True).start()

    def restart_pwnagotchi(self):
        time.sleep(self.restart_delay)

        if self.restart_mode == "reboot":
            subprocess.call(["reboot"])
        else:
            subprocess.call(["systemctl", "restart", "pwnagotchi"])

    def on_unload(self, ui):
        try:
            GPIO.remove_event_detect(self.button_pin)
        except Exception:
            pass
